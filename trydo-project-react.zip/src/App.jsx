
import './App.css'
import CardsFeatures from './component/CardsFeatures/CardsFeatures'
import Facts from './component/facts/Facts'
import Footer from './component/footer/Footer'
import Header from './component/header/Header'
import Navbar from './component/navbar/Navbar'
import News from './component/news/News'
import PortFolio from './component/portfolio/PortFolio'
import Customer from './component/sustomergallery/Customer'
import Team from './component/team/Team'

function App() {


  return (
    <>

      <section className='bg-black '>
        <Navbar />
        <Header />

      </section>
      <section className='bg-[#191919] '>
        <CardsFeatures />

      </section>
      <section className='bg-black'>
        <PortFolio />

      </section>
      <section className='bg-[#191919] '>
        <Facts />

      </section>
      <section className='bg-[#f8f9fc] '>
        <Team />

      </section>
      <section className='bg-white '>
        <Customer/>

      </section>
      <section className='bg-[#f8f9fc] '>
       <News/>

      </section>
      <section className='bg-[#1c1d23] '>
      <Footer/>

      </section>
    </>
  )
}

export default App
