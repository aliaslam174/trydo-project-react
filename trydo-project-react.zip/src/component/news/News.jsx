import React from 'react'

function News() {
    return (
        <>
            <div className='  container mx-auto py-28 grid grid-cols-1'>
                <h1 className='text-5xl font-bold mb-4'>Latest News</h1>
                <p className='text-[#717173] mb-8 text-[18px]'>There are many variations of passages of Lorem Ipsum available,<br />
                    but the majority have suffered alteration.</p>
            </div>
        </>
    )
}

export default News