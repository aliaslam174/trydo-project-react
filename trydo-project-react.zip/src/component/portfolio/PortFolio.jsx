import React from 'react'

function PortFolio() {
  return (
    <>
    <div className=' text-white container mx-auto py-28'>
    <h1 className='text-5xl font-bold mb-4'>Our Portfolio</h1>
    <p className='text-[#c6c9d8] mb-8 text-[18px]'>There are many variations of passages of Lorem Ipsum available,<br />
but the majority have suffered alteration.</p>
    </div>
    
    
    </>
  )
}

export default PortFolio