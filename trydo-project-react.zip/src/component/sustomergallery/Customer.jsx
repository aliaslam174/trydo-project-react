import React from 'react'

function Customer() {
  return (
    <>
    
    <div className='container mx-auto  p-44 text-center'>
        <p className='text-[32px] font-medium'>Phenomenal Customer Service! I'm just starting out with the team helped me so much with integrating this into my website. Highly recommend.</p>
        <p>FATIMA ASRAFY - COO, AMERIMAR ENTERPRISES, INC.</p>
        <div></div>
    </div>
    </>
  )
}

export default Customer